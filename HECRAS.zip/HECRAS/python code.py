# -*- coding: utf-8 -*-
"""
Created on Mon Mar 10 22:04:52 2025

@author: rutvi
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import bisect


g = 9.81  
Q = 10    #given discharge
n = 0.013 #manning's roughness coefficient

#defining channel classes
class TrapezoidalChannel:
    def __init__(self, b, z, S):
        self.b = b  # Bottom width (m)
        self.z = z  # Side slope (H:V)
        self.S = S  # Channel slope

    def area(self, y):
        return y * (self.b + self.z * y)  #A = y * (b + zy)

    def perimeter(self, y):
        return self.b + 2 * y * (1 + self.z**2) ** 0.5  

    def hydraulic_radius(self, y):
        return self.area(y) / self.perimeter(y)  #R = A/P

    def normal_depth_eq(self, y):
        A = self.area(y)
        R = self.hydraulic_radius(y)
        return (1/n) * A * R**(2/3) * self.S**(1/2) - Q  #manning's equation

    def critical_depth_eq(self, y):
        A = self.area(y)
        T = self.b + 2 * self.z * y  
        return Q - A * (g * A / T) ** 0.5  #critical depth equation

class RectangularChannel:
    def __init__(self, b, S):
        self.b = b  #width
        self.S = S  #channel slope

    def area(self, y):
        return self.b * y  

    def perimeter(self, y):
        return self.b + 2 * y  

    def hydraulic_radius(self, y):
        return self.area(y) / self.perimeter(y)

    def normal_depth_eq(self, y):
        A = self.area(y)
        R = self.hydraulic_radius(y)
        return (1/n) * A * R**(2/3) * self.S**(1/2) - Q

    def critical_depth_eq(self, y):
        A = self.area(y)
        T = self.b  
        return Q - A * (g * A / T) ** 0.5


trapezoidal = TrapezoidalChannel(b=5, z=1.5, S=0.0008)   #defining channel
rectangular_upper = RectangularChannel(b=4, S=0.0012)
rectangular_lower = RectangularChannel(b=4, S=0.0024)

#normal n critical depths
y_n_trapezoidal = bisect(trapezoidal.normal_depth_eq, 0.01, 5)
y_c_trapezoidal = bisect(trapezoidal.critical_depth_eq, 0.01, 5)

y_n_rect_upper = bisect(rectangular_upper.normal_depth_eq, 0.01, 5)
y_c_rect_upper = bisect(rectangular_upper.critical_depth_eq, 0.01, 5)

y_n_rect_lower = bisect(rectangular_lower.normal_depth_eq, 0.01, 5)
y_c_rect_lower = bisect(rectangular_lower.critical_depth_eq, 0.01, 5)

#plottinh water surfave profile
x_trap = np.linspace(0, 200, 100)
x_upper = np.linspace(200, 350, 100)
x_lower = np.linspace(350, 600, 100)

bottom_trap = -trapezoidal.S * x_trap
bottom_upper = bottom_trap[-1] - rectangular_upper.S * (x_upper - x_upper[0])
bottom_lower = bottom_upper[-1] - rectangular_lower.S * (x_lower - x_lower[0])

plt.figure(figsize=(10, 6))
plt.plot(x_trap, bottom_trap + y_n_trapezoidal, 'b--', label="Normal Depth")
plt.plot(x_upper, bottom_upper + y_n_rect_upper, 'b--')
plt.plot(x_lower, bottom_lower + y_n_rect_lower, 'b--')

plt.plot(x_trap, bottom_trap + y_c_trapezoidal, 'r--', label="Critical Depth")
plt.plot(x_upper, bottom_upper + y_c_rect_upper, 'r--')
plt.plot(x_lower, bottom_lower + y_c_rect_lower, 'r--')

plt.plot(np.concatenate([x_trap, x_upper, x_lower]),
         np.concatenate([bottom_trap, bottom_upper, bottom_lower]), 'k', label="Channel Bottom")

plt.xlabel("Channel Length (m)")
plt.ylabel("Elevation (m)")
plt.legend()
plt.title("Water Surface Profile (Normal & Critical Depth)")
plt.grid()
plt.show()

#cross section plotting
def plot_cross_section(channel, y_n, y_c, title):
    y_range = np.linspace(0, max(y_n, y_c) + 0.5, 20)
    if isinstance(channel, TrapezoidalChannel):
        x_left = -channel.z * y_range
        x_right = channel.z * y_range + channel.b
    else:
        x_left = np.zeros_like(y_range)
        x_right = np.full_like(y_range, channel.b)
    
    plt.figure(figsize=(6, 5))
    plt.fill_betweenx(y_range, x_left, x_right, color='lightpink', label="Water Depth")
    plt.axhline(y_n, color='r', linestyle='--', label='Normal Depth')
    plt.axhline(y_c, color='g', linestyle='--', label='Critical Depth')
    plt.xlabel("Width (m)")
    plt.ylabel("Depth (m)")
    plt.title(title)
    plt.legend()
    plt.grid()
    plt.show()

plot_cross_section(trapezoidal, y_n_trapezoidal, y_c_trapezoidal, "Trapezoidal Channel Cross-Section")
plot_cross_section(rectangular_upper, y_n_rect_upper, y_c_rect_upper, "Upper Rectangular Reach Cross-Section")
plot_cross_section(rectangular_lower, y_n_rect_lower, y_c_rect_lower, "Lower Rectangular Reach Cross-Section")

#printing depths
print("Normal and Critical Depths:")
print(f"Trapezoidal Channel: Normal Depth = {y_n_trapezoidal:.3f} m, Critical Depth = {y_c_trapezoidal:.3f} m")
print(f"Rectangular Upper Reach: Normal Depth = {y_n_rect_upper:.3f} m, Critical Depth = {y_c_rect_upper:.3f} m")
print(f"Rectangular Lower Reach: Normal Depth = {y_n_rect_lower:.3f} m, Critical Depth = {y_c_rect_lower:.3f} m")


from scipy.optimize import fsolve

class StandardStepMethod:
    def __init__(self, channel, x_start, x_end, dx, y_start, n, Q):
        self.channel = channel
        self.x_values = np.arange(x_start, x_end + dx, dx)
        self.y_values = [y_start]
        self.n = n
        self.Q = Q  
    
    def step_solve(self):
        for i in range(1, len(self.x_values)):
            x_prev = self.x_values[i - 1]
            y_prev = self.y_values[i - 1]

            
            A_prev = self.channel.area(y_prev)    #previous values
            P_prev = self.channel.perimeter(y_prev)
            R_prev = A_prev / P_prev
            Sf_prev = (self.n ** 2) * (self.Q ** 2) / (A_prev ** (10/3)) * (R_prev ** (-4/3))  # Manning’s friction slope

            
            def equation(y):
                A_curr = self.channel.area(y)
                P_curr = self.channel.perimeter(y)
                R_curr = A_curr / P_curr
                Sf_curr = (self.n ** 2) * (self.Q ** 2) / (A_curr ** (10/3)) * (R_curr ** (-4/3))  
                return y - y_prev + (self.channel.S - Sf_curr) * (self.x_values[i] - x_prev)
            
            
            y_next = fsolve(equation, y_prev)[0]  #initial guess: previous depth
            self.y_values.append(y_next)
    
    def plot_profile(self):
        plt.figure(figsize=(10, 6))
        plt.plot(self.x_values, self.y_values, label='Water Surface Profile (Standard Step)')
        plt.xlabel('Channel Length (m)')
        plt.ylabel('Water Depth (m)')
        plt.title('Water Surface Profile using Standard Step Method')
        plt.legend()
        plt.grid()
        plt.show()

#plotting by standard step method
step_method_trap = StandardStepMethod(trapezoidal, 0, 200, 10, y_n_trapezoidal, 0.013,10)
step_method_trap.step_solve()
step_method_trap.plot_profile()

step_method_upper = StandardStepMethod(rectangular_upper, 200, 350, 10, y_n_rect_upper, 0.013,10)
step_method_upper.step_solve()
step_method_upper.plot_profile()

step_method_lower = StandardStepMethod(rectangular_lower, 350, 600, 10, y_n_rect_lower, 0.013,10)
step_method_lower.step_solve()
step_method_lower.plot_profile()



plt.figure(figsize=(12, 6))

#normal profile
plt.plot(x_trap, bottom_trap + y_n_trapezoidal, 'b--', label="Normal Depth")
plt.plot(x_upper, bottom_upper + y_n_rect_upper, 'b--')
plt.plot(x_lower, bottom_lower + y_n_rect_lower, 'b--')

#critical profile
plt.plot(x_trap, bottom_trap + y_c_trapezoidal, 'r--', label="Critical Depth")
plt.plot(x_upper, bottom_upper + y_c_rect_upper, 'r--')
plt.plot(x_lower, bottom_lower + y_c_rect_lower, 'r--')

#std step profile
plt.plot(step_method_trap.x_values, np.array(step_method_trap.y_values) + bottom_trap[:len(step_method_trap.x_values)], 'g-', label="Standard Step Method")
plt.plot(step_method_upper.x_values, np.array(step_method_upper.y_values) + bottom_upper[:len(step_method_upper.x_values)], 'g-')
plt.plot(step_method_lower.x_values, np.array(step_method_lower.y_values) + bottom_lower[:len(step_method_lower.x_values)], 'g-')

#bottom
plt.plot(np.concatenate([x_trap, x_upper, x_lower]),
         np.concatenate([bottom_trap, bottom_upper, bottom_lower]), 'k', label="Channel Bottom")


plt.xlabel("Channel Length (m)")
plt.ylabel("Elevation (m)")
plt.legend()
plt.title("Water Surface Profiles: Normal, Critical & Standard Step Method")
plt.grid()
plt.show()

